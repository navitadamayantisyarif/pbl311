# Network Configuration Fix Documentation

## Masalah yang Diperbaiki

Tombol "Kunci" di DoorScreen.kt tidak berfungsi karena konfigurasi network menggunakan IP address yang tidak dapat diakses dari Android emulator.

## Root Cause Analysis

### 1. Base URL Configuration
- ❌ **Sebelum**: `http://10.239.140.163:3000/api/`
- ✅ **Sesudah**: `http://10.0.2.2:3000/api/`

### 2. Android Emulator Network Mapping
- **10.239.140.163** - IP address host machine yang tidak dapat diakses dari emulator
- **10.0.2.2** - IP address yang dipetakan ke localhost (127.0.0.1) dari Android emulator

## Perbaikan yang Diterapkan

### StorageNetworkModule.kt
```kotlin
// Sebelum
.baseUrl("http://10.239.140.163:3000/api/")

// Sesudah  
.baseUrl("http://10.0.2.2:3000/api/")
```

## Penjelasan Network Mapping

### Android Emulator Network
- **10.0.2.1** - Router/gateway emulator
- **10.0.2.2** - Host machine (localhost dari emulator)
- **10.0.2.3** - First DNS server
- **10.0.2.4** - Second DNS server

### Host Machine Network
- **127.0.0.1** - Localhost
- **10.239.140.163** - IP address network interface
- **localhost** - Domain name untuk 127.0.0.1

## Testing Checklist

### Backend Testing
- [ ] Server berjalan di localhost:3000
- [ ] API endpoint `/api/door/control` dapat diakses
- [ ] Response format sesuai dengan yang diharapkan

### Android App Testing
- [ ] Network request berhasil dikirim
- [ ] Response diterima dengan benar
- [ ] Door status berubah setelah control
- [ ] UI update sesuai dengan response

### Integration Testing
- [ ] End-to-end flow: klik "Kunci" → API call → response → UI update
- [ ] Error handling untuk network issues
- [ ] Loading state ditampilkan dengan benar

## Alternative Solutions

### 1. Untuk Physical Device
Jika menggunakan physical device, gunakan IP address host machine:
```kotlin
.baseUrl("http://10.239.140.163:3000/api/")
```

### 2. Untuk Production
Gunakan domain name atau IP address production:
```kotlin
.baseUrl("https://api.smartdoor.com/api/")
```

### 3. Untuk Development dengan Different Port
```kotlin
.baseUrl("http://10.0.2.2:8080/api/")
```

## Network Security Considerations

### 1. HTTP vs HTTPS
- **Development**: HTTP (tidak aman, untuk testing)
- **Production**: HTTPS (aman, untuk production)

### 2. Certificate Pinning
Untuk production, pertimbangkan certificate pinning:
```kotlin
val certificatePinner = CertificatePinner.Builder()
    .add("api.smartdoor.com", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
    .build()
```

### 3. Network Security Config
Tambahkan network security config untuk production:
```xml
<network-security-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">api.smartdoor.com</domain>
    </domain-config>
</network-security-config>
```

## Debugging Network Issues

### 1. Check Network Connectivity
```bash
# Test dari emulator
adb shell ping 10.0.2.2

# Test dari host machine
ping localhost
```

### 2. Check Server Status
```bash
# Test API endpoint
curl http://localhost:3000/api/door/status
```

### 3. Check Android Logs
```bash
# Monitor network requests
adb logcat | grep -i "okhttp\|retrofit\|network"
```

## Dampak Perbaikan

### 1. Network Connectivity
- ✅ Android emulator dapat mengakses backend server
- ✅ API calls berhasil dikirim dan diterima
- ✅ Door control berfungsi dengan benar

### 2. User Experience
- ✅ Tombol "Kunci" berfungsi
- ✅ Door status berubah sesuai action
- ✅ UI update real-time
- ✅ Error handling yang baik

### 3. Development Experience
- ✅ Debugging lebih mudah dengan localhost
- ✅ Testing lebih reliable
- ✅ Development workflow lebih smooth

## Kesimpulan

Perbaikan network configuration dari `10.239.140.163` ke `10.0.2.2` menyelesaikan masalah konektivitas antara Android emulator dan backend server. Sekarang:

1. ✅ **Network connectivity** - Emulator dapat mengakses backend
2. ✅ **API calls** - Request dan response berfungsi
3. ✅ **Door control** - Tombol "Kunci" berfungsi dengan benar
4. ✅ **UI updates** - Status door berubah sesuai action

**Masalah tombol "Kunci" telah diperbaiki dengan mengubah konfigurasi network!** 🎉
